import React, { Component } from 'react'
import Web3 from 'web3'
import logo from '../logo.png'
import './App.css'
import Express from '../abis/Express'
import Addressbar from './Addressbar'
import { withRouter } from 'react-router'
import Courier from './Courier'

class App extends Component {
  state = {
    account: '',
    totalNumber: 0,
    items: [],
    loading: false,
    CourierBtn:true,

  }



  async componentDidMount() {
    await this.getWeb3Provider()
    await this.connectToBlockchain()
  }

  async getWeb3Provider() {
    if (window.ethereum) {
      window.web3 = new Web3(window.ethereum)
      await window.ethereum.enable()
    } else if (window.web3) {
      window.web3 = new Web3(window.web3.currentProvider)
    } else {
      window.alert(
        'Non-Ethereum browser detected. You should consider trying MetaMask!',
      )
    }
  }

  async connectToBlockchain() {
    const web3 = window.web3
    const accounts = await web3.eth.getAccounts()
    this.setState({ account: accounts[0] })
    const networkId = await web3.eth.net.getId()
    const networkData = Express.networks[networkId]
    if (networkData) {
      const deployedExpress = new web3.eth.Contract(
        Express.abi,
        networkData.address,
      )
      this.setState({ deployedExpress: deployedExpress })
      const totalNumber = await deployedExpress.methods.totalNumber().call()
      console.log(totalNumber)
      this.setState({ totalNumber })
    } else {
      window.alert('Express contract is not found in your blockchain.')
    }
  }



  render() {
    return (
      <div>
       <Addressbar account={this.state.account} />
       <div className="container-fluid mt-5">

       <button onClick={this.ParcelSender.bind(this)}>ParcelSender</button>
        <button onClick={this.Courier.bind(this)}>Courier</button>
        <button onClick={this.Receiver.bind(this)}>Receiver</button>
     

                 
           
        </div>
      </div>
    )
  }
  ParcelSender = () => {
    var account = this.state.account;
   this.props.history.push({pathname:'/ParcelSender', query:{account}})
  }  

  Courier = () => {
    var account = this.state.account;
   this.props.history.push({pathname:'/Courier', query:{account}})

  }

  Receiver = () => {
    var account = this.state.account;
   this.props.history.push({pathname:'/Receiver', query:{account}})
  }

}


export default App
