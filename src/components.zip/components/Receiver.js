import React, { Component } from 'react'
import Addressbar from './Addressbar'
class Receiver extends Component {
  state = {
      recvData: {},
    }
  async componentDidMount() {
    let recvParam
    if (this.props.location && this.props.location.query) {
      //To see if parameters exist
      recvParam = this.props.location.query;
      sessionStorage.setItem('recvData', JSON.stringify(recvParam)) // store recvParam in sessionStorage
    } else {
      recvParam =  JSON.parse(sessionStorage.getItem('recvData'));
    }
    this.setState({
      recvData: recvParam
    })
    console.log('recvParam', recvParam);
  }

  render() {
    return (
    
      <div>
       <Addressbar account={this.state.recvData.account} />
       <div className="container-fluid mt-5">
      <div id="content">{this.state.recvData.account}</div>
      
      
      </div>
      </div>
      
      )}
}

export default Receiver
